package org.pinky.code.my.module
import com.google.inject.name.Names._
import com.google.inject._
import org.pinky.code.extension._
import org.pinky.code.extension.controlstructure._

class RepresentationModule extends AbstractModule {
    
     
    protected def configure{
      bind(classOf[Representation]).annotatedWith(named("rss")).to(classOf[RssRepresentation])
      bind(classOf[Representation]).annotatedWith(named("html")).to(classOf[HtmlRepresentationVelocity])
      bind(classOf[Representation]).annotatedWith(named("xml")).to(classOf[XmlRepresentation])
      bind(classOf[Representation]).annotatedWith(named("json")).to(classOf[JsonRepresentationJsonLib])
      bind(classOf[Representations]).to(classOf[DefaultRepresentations])
      bind(classOf[BaseControl]).to(classOf[DefaultControl])
    }
}
